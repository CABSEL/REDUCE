function [vko_star,i_star,e_star]=reduce(gu,gl,essential_set,max_ko)



% reduce (reduction of uncertain edge): optimization of gene knock-out (ko)
% experiments for gene regulatory network inference
%
% this matlab script implements a genetic algorithm (ga) for optimizing
% the combination of genes whose removal would enable the verification
% of the most uncertain edges. the algorithm is described in detail
% in our manuscript titled: "optimal design of gene knock-out
% experiments for inferring gene regulatory networks".
%
% prerequisite: python with numpy
%
% inputs:
% essential_set: indices of genes to be excluded from ko
% gu: the upper bound matrix of the grn ensemble
% gl: the lower bound matrix of the grn ensemble
% gu and gl matrices should be set such that the (i,j)-th element is 1
% when the edge (i,j) belongs to the bound, and 0 otherwise.
% max_ko: constraint on the maximum number of genes in a ko experiment
%
% outputs:
% vko_star: the optimal set of genes for ko (a vector of gene indices)
% i_star: the set of genes which should be perturbed individually in
% the background of vko_star ko (a vector of gene indices)
% e_star: the set of uncertain edges to be verified by the optimal ko
% experiment. the first column gives the indices of the regulating genes,
% and the second column gives the indices of the regulated genes.
%
% optimization parameters:
% pop_size: population size in ga
% num_gen: number of generations in ga
% num_block: number of division blocks during crossover in ga
% mut_rate: mutation rate in ga
%
% note that as ga is a stochastic optimization strategy, the outputs
% may change from one run to another.
%
% created by s.m. minhaz ud-dean
% designed by s.m. minhaz ud-dean and rudiyanto gunawan
% date: 5 oct 2015

%set optimization parameters
n=size(gu,1); %number of genes in the network
num_gen=100;
% num_replicate=10;
pop_size=100;
num_block=6;
mut_rate=0.1;
dlmwrite('essential_list.csv',essential_set');
acc=gu; %the initial upper bound

if ~isequal(gu,gl)  %% check if the bounds meet
    try
        [ranking,rv,rows,columns,sep_list,edges]=...
            genetic_algorithm_rank_python_bu...
            (gu,gl,acc,num_gen,max_ko,pop_size,num_block,mut_rate);
        if isempty(rv)
            rv=0;
        end
    catch err1
        ranking=[];
        rv=0;
        rows=[];
        columns=[];
        sep_list=[];
    end
    try
        [ranking1,rv1,rows1,columns1,sep_list1,edges1]=...
            genetic_algorithm_rank_python...
            (gu,gl,acc,num_gen,max_ko,pop_size,num_block,mut_rate);
        if isempty(rv1)
            rv1=0;
        end
    catch err2
        ranking1=[];
        rv1=0;
        rows1=[];
        columns1=[];
        sep_list1=[];
    end
    try
        [ranking2,rv2,rows2,columns2,sep_list2,edges2]=...
            genetic_algorithm_rank_python_acc...
            (gu,gl,acc,num_gen,max_ko,pop_size,num_block,mut_rate);
        if isempty(r2v)
            rv2=0;
        end
    catch err3
        ranking2=[];
        rv2=0;
        rows2=[];
        columns2=[];
        sep_list2=[];
    end
    %     ga_time=toc;
    % [rv(1),rv1(1),rv2(1)]
    [~,idx]=max([rv(1),rv1(1),rv2(1)]);
    
    if idx==1
        
    elseif idx==2
        ranking=ranking1;
        rv=rv1;
        rows=rows1;
        columns=columns1;
        sep_list=sep_list1;
        edges=edges1;
    elseif idx==3
        ranking=ranking2;
        rv=rv2;
        rows=rows2;
        columns=columns2;
        sep_list=sep_list2;
        edges=edges2;
    end
    ko_list=ranking(1,:);
    row=rows(1,:);
    column=columns(1,:);
    edge=edges(1,1:end-1);
    edge(edge==0)=[]; %remove zeros
end
e_star=zeros(floor(length(edge)/2),2);
for kk=1:floor(length(edge)/2)
    e_star(kk,:)=edge(2*kk-1:2*kk);
end


vko_star=setdiff(ko_list,0);

i_star=setdiff(row,0);



end