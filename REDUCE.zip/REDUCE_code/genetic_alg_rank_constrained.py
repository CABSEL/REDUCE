#!/usr/bin/python
import numpy as np
#import msvcrt
###Module GA for optimization of a mattlab output separator list

## function select parents
def    select_parents(population, val, frac, sorted):
    """ Selects parents from a population based on fitness function 
    and given fraction.
    """
    len_sep_list=len(population)
    # Initialize population
    if sorted==0:
        m=np.array(val)
        c=m.ravel().argsort()
        c=c[::-1]
        rerank=[]
        val2=[]
        for cs in c:
            val2.append(val[cs])
            rerank.append(population[cs])
    elif sorted==1:
        rerank=population
        val2=val
    else:
        print('Set Sorted Value to 1 for Sorted population, and 0 for undorted Population.');

    if len_sep_list<100:
        frac=len_sep_list
    elif frac<1:
        frac=np.int(np.ceil(frac*len_sep_list))  
        frac=max(frac,100)
    #print(frac)
    #print(len_sep_list)
    r=[]
    r.append(rerank[0:frac])    
    r.append(val2[0:frac])
    return r
    
    
## function mate
def    mate(parents, num_offsprings, category, num_blocks):
    """ Generate offsprings based on selected parents and recombination 
    method."""
    parents=np.array(parents)
    n=len(parents[0])
    num_parents=len(parents)
    offsprings=np.zeros((num_offsprings,n))
    i=0;
    while  i<num_offsprings:
        parent1=np.floor(np.random.rand()*(num_parents)-0.00000001)
        parent2=np.floor(np.random.rand()*(num_parents)-0.00000001)    
        if parent1>=num_parents or parent2>=num_parents:
            continue    
        if category=='random':
            mask = np.zeros(n)
            mask[:np.int(np.ceil(n/2))]= 1;
            np.random.shuffle(mask)
            mask=mask.reshape(1,n)
            counter_mask=np.ones((1,n))-mask
        
        elif category=='midpoint':
            mask=np.zeros((1,n))
            mask[1:np.int(np.ceil(n/2))]=1
            counter_mask=np.ones((1,n))-mask      
        
        
        
        elif category=='multiblock':
            mask=np.zeros((1,n));
        
            for j in range(num_blocks):
                if np.mod(j,2)==0:
                    mask[np.int(np.ceil(j*n/num_blocks)):np.int(np.ceil((j+1)*n/num_blocks))]=1;
                else:
                    pass
            counter_mask=np.ones((1,n))-mask;
        
        else: 
            print('Set type to either "random", "midpoint" or "multiblock". For "multiblock" also mention the number of blocks as the 4th arguments.');
    
    
        offsprings[i,:]=mask*parents[parent1,:]+counter_mask*parents[parent2,:]
    
        if offsprings[i,:].sum()!=0:       
            i=i+1;
    
    return offsprings

#function mutate
def mutate(offsprings,mutation_rate):
    '''Adds random mutation in the offsprings.
    '''
    mutation_rate=1+mutation_rate
    mutated=[]
    for child in offsprings:
        mutant_child=[]
        for gene in child:
            if mutation_rate*np.random.rand()>1:
                if gene==1:
                    mutant_gene=0
                elif gene==0:
                    mutant_gene=1
                else:
                    mutant_gene=0
            else:
                mutant_gene=gene
            mutant_child.append(mutant_gene) 
        mutated.append(mutant_child)                  

    return mutated    
    
## Function num_separated
def num_separated(seps,seps2,essential_list,max_ko):   
    """compares two list of separators and returns the separation
    value of the second list"""
    k=[];
    seps_set=[]
    essential_set=[]
    outs=[]
    ins=[]
    
  
        
    for line in essential_list:
        b=set(line)
        if 0 in b:
            b.remove(0)    
        essential_set.append(b)  
        
    if len(essential_list)==len(essential_set):
        iterator1=xrange(len(essential_list))    
  
    for line in seps:
        b=set(line[2:])
        if 0 in b:
            b.remove(0)    
        seps_set.append(b)  
        outs.append(line[0])
        ins.append(line[1])
        
    if len(seps)==len(seps_set):
        iterator2=xrange(len(seps))
    
    for row in seps2:
        i=0;
        a=set(row[2:])
        contains_essential=0; #flag to check whether the current separator 
                             #contains an essential gene combination
        if 0 in a:
            a.remove(0)
            
        if max_ko!=0 and len(a) > max_ko:
            k.append(0);
            continue
        
        for jj in iterator1:
            b=essential_set[jj]
            if b.issubset(a):
                contains_essential=1
                break
       
        if contains_essential==1:   
            k.append(0);
            continue
       
        for ii in iterator2:
            b=seps_set[ii]                   
            if not(outs[ii] in a) and not(ins[ii] in a) and (b.issubset(a)):
                i+=1         
        
        k.append(i)   
        
    m=np.array(k)
    c=m.ravel().argsort()
    c=c[::-1]
    val=[]
    seps_sorted=[]
    for cs in c:
        val.append(k[cs])
        seps_sorted.append(seps2[cs][2:])   
   
    r=(seps_sorted,val,seps_set, outs, ins, essential_set )
    return r 
    
## Function num_separated2    

def num_separated2(seps_set,seps2, outs, ins, essential_set,max_ko):   
    """
    compares a list of separators with a lsit of separators and returns the 
    separation value of the   second list. The edges are not required for 
    the second list.
    """
    k=[];
    iterator1=xrange(len(essential_set))    
    iterator2=xrange(len(seps_set))    
    
    for row in seps2:
        i=0;
        a=set(row)
        contains_essential=0; #flag to check whether the current separator 
                             #contains an essential gene combination
        if 0 in a:
            a.remove(0)
            
        if max_ko!=0 and len(a) > max_ko:
            k.append(0);
            continue
        
        for jj in iterator1:
            b=essential_set[jj]
            if b.issubset(a):
                contains_essential=1
                break
       
        if contains_essential==1:   
            k.append(0);
            continue
        
        for ii in iterator2:
            b=seps_set[ii]                   
            if not(outs[ii] in a) and not(ins[ii] in a) and (b.issubset(a)):
                i+=1         
        k.append(i)        
    return k    
    
## function compete select
def compete_select(population, rerank_values_prev,offsprings,frac,
                       seps_set, outs, ins, essential_set,max_ko):  
    '''
     selects for the survival in the next generation based on num_separated
    '''
    population_next=[];
    for i in population:
        i=list(i)
        population_next.append(i)
    for i in offsprings:
        i=list(i)
        population_next.append(i)
       
    number_individuals=len(population_next);

    fitness=[ii for ii in rerank_values_prev];
    
    seps2=[];
    
    for individual in offsprings:
        
        indices=[ii+1 for ii  in range(len(individual)) if individual[ii]]  #i+1 for matlab compatibility     
        seps2.append(indices)


    val = num_separated2(seps_set,seps2, outs, ins, essential_set,max_ko)
   
    for i in val:
        fitness.append(i)  
        
    m=np.array(fitness)
    c=m.ravel().argsort()
    c=c[::-1]

    if frac<=1:
        frac=np.int(np.ceil(frac*number_individuals))
        frac=max(frac,100)
        
    val=[]
    seps_sorted=[]
    for cs in c:
         val.append(fitness[cs])
         seps_sorted.append(population_next[cs])   
    r=[]
    r.append(seps_sorted[0:frac-1])    
    r.append(val[0:frac-1])
    return r    
    

   

def   genetic_alg_rank_constrained(sep_list,num_gen,n,essential_list,max_ko,pop_size,num_block,mut_rate):
    '''
    uses genetic algorithm to find the optimum separator based on known separators    '''
   
    if  not sep_list:
        ranking=[];
        rerank_values=[];
        r=(ranking,rerank_values)
        return r
    elif len(sep_list)<=1:
        ranking=sep_list;
        rerank_values=[1];
        r=(ranking,rerank_values)
        return r

    rv=num_separated(sep_list,sep_list,essential_list,max_ko)

    seps_set=rv[2]
    outs=rv[3]    
    ins=rv[4]
    essential_set=rv[5]

    

    #rank
    rerank=[];
    rerank_values=rv[1];

    for sep in rv[0]:
        sep_set=set(sep);
        if 0 in sep_set:
            sep_set.remove(0)
        index=np.array(list(sep_set))-1 #to be compatible with matlab
        a=np.zeros(n)
        a[index]=1;
        rerank.append(a)



    for gen in range(num_gen):
        population=rerank #Initialize Population   
        #Select Parent
        frac=0.5
        rv=select_parents(population,rerank_values,frac,1)
        parents=rv[0]
    
        #crossover
        num_offsprings=min([np.int(np.ceil(len(population)*1.0)), 50])
        offsprings=mate(parents,num_offsprings,'multiblock',6)
    
        #mutate
        mutation_rate=0.1;
        offsprings=mutate(offsprings,mutation_rate)
    
        #compete &  select next population
        frac=0.5;
        #rv=compete_select(population,rerank_values, offsprings,sep_list, frac);
        rv=compete_select(population, rerank_values,offsprings,frac,
                       seps_set, outs, ins, essential_set,max_ko)
        rerank=rv[0];
        rerank_values=rv[1]
    
        #check convergence
    
        #print(gen)
        if max(rerank_values)==min(rerank_values):
            pass #break
        elif gen==0:
            max_now=max(rerank_values);
            min_now=min(rerank_values);        
        elif gen>1:
            max_prev=max_now;
            min_prev=min_now;
            max_now=max(rerank_values);
            min_now=min(rerank_values);
            if max_now==max_prev and min_now==min_prev:
                pass
        

    ranking=[];
    check_rows=[];
    check_columns=[];
    check_edges=[];
    iterator2=xrange(len(seps_set))    

    
    for sep in rerank:
        indices=[i+1 for i  in range(len(sep)) if sep[i]]  #to be compatible with matlab
        ranking.append(indices)
        a=set(indices)
        chk_row=[];
        chk_column=[];
        chk_edge=[];
        for ii in iterator2:
            b=seps_set[ii]                   
            if not(outs[ii] in a) and not(ins[ii] in a) and (b.issubset(a)):
                chk_row.append(outs[ii])
                chk_column.append(ins[ii])
                chk_edge.append([outs[ii],ins[ii]])
        check_rows.append(list(set(chk_row)      ))
        check_columns.append(list(set(chk_column)))
        check_edges.append(chk_edge);
            
        
    r=(ranking,rerank_values,check_rows,check_columns,check_edges  )
    return r        
