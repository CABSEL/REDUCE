function [ranking,rank_values,rows,columns,sep_list,edges]=...
    genetic_algorithm_rank_python_bu(gu,gl,acc,num_gen,max_ko,...
    pop_size,num_block,mut_rate)

% This function calculates optimum  separatoid to verify the edges (i,j) in gu but not
% in gl using the intersection of intersection of  children of i in gu and ancestors of j
% in acc. The bounds may contain cycles.
%
%inputs
% gu= upper bound
% gl=lower bound
% acc=initial upper bound/error free accessibility matrix
% max_ko= maximum number of genes KO togetehr in the sepratoid
% essential_set: indices of genes to be excluded from KO
% pop_size: population size in GA
% num_gen: number of generations in GA
% num_block: number of division blocks during crossover in GA
% mut_rate: mutation rate in GA

%outputs
% ranking=list of separatoids in order of the number of edges verified by
% each separatoid
% rank_values= number of  edges verified by each separatoid in ranking
% rows= {i:(i,j) verifiable by separatoid in ranking} stacked in the same
% order as the separatoids in ranking
% columns= {j:(i,j) verifiable by separatoid in ranking} stacked in the same
% order as the separatoids in ranking
% sep_list= the list of separatoids used in optimization

if (size(gu,1)==size(gu,2) && isequal(size(gl),size(gu)) )
    n=length(gu);
else
    error('Invalid Input. Input valid upper and lower bounds');
end

%generate initial population
if isequal(gu,gl) || isempty(acc)
    ranking=[];
    rank_values=0;
    rows=0;
    columns=0;
    return
end
sep_list=sep_list_bound_cycle_bu(gu,gl,acc);%calclate separatoids

if size(sep_list)==1 % no need to optimize
   ranking= sep_list(:,3:end);
   rank_values=1;
   rows=seplist(1,1);
   columns=seplist(1,2);
   return
end

delete('ga_result.csv') %remove outputs from previous run
delete('val.csv') %remove outputs from previous run
delete('columns.csv') %remove outputs from previous run
delete('rows.csv') %remove outputs from previous run
delete('ga_parameters.inp') %remove outputs from previous run
ga_parameters=[num_gen,n,max_ko,pop_size,num_block,mut_rate]; 
dlmwrite('ga_parameters.inp', ga_parameters); %save ga parameters for python

dlmwrite('sep_list.csv', sep_list); %save the separator list

system('python optimize.py');

rerank=dlmread('ga_result.csv'); %Read Python output
rank_values=dlmread('val.csv'); %Read Python output
rows=dlmread('rows.csv'); %Read python output
columns=dlmread('columns.csv'); %Read python output
edges=dlmread('edges.csv'); %Read python output

delete('sep_list.csv'); %delete separator list 


ranking=rerank;

end