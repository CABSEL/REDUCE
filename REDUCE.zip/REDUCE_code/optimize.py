import genetic_alg_rank_constrained as garc



with open('ga_parameters.inp') as f:
    parameters =[ [float(x) for x in line.split(',')] for line in f]
    
num_gen=int(parameters[0][0])
n=int(parameters[0][1])

try:
    max_ko=int(parameters[0][2])
except:
    max_ko=n

try:
    pop_size=int(parameters[0][3])
except:
    pop_size=100
    
try:
    num_block=int(parameters[0][4])
except:
    num_block=6

try:
    mut_rate=float(parameters[0][4])
except:
    mut_rate=0.1
    	
    
try:
    with open('sep_list.csv') as f:
        sep_list = [[int(x) for x in line.rstrip().split(',') if x] for line in f]
except:
    sep_list=[]        
    
try:
    with open('essential_list.csv') as f:
        essential_list = [[int(x) for x in line.rstrip().split(',') if x] for line in f]
except:
    essential_list=[[n+1]]    

r=garc.genetic_alg_rank_constrained(sep_list,num_gen,n,essential_list,max_ko,pop_size,num_block,mut_rate)


a=r[0];
f = open('ga_result.csv', 'w')     

for i in a:    
    for item in i:
         f.write("%s," % item)
    f.write("\n" )   
    
f.close()

f = open('val.csv', 'w')     

for i in r[1]:    
    f.write("%s\n" % i)     
f.close()    

a=r[2];
f = open('rows.csv', 'w')     

for i in a:    
    for item in i:
         f.write("%s," % item)
    f.write("\n" )   
    
f.close()     

a=r[3];
f = open('columns.csv', 'w')     

for i in a:    
    for item in i:
         f.write("%s," % item)
    f.write("\n" )   
    
f.close()   


a=r[4];
f = open('edges.csv', 'w')     

for i in a:    
    for item in i:
         for j in item:
             f.write("%s," % j)
    f.write("\n" )   
    
f.close()   