function s=sep_list_bound_cycle(gu,gl,acc)
% This function calculates list of separatoids for the edges (i,j) in gu but not
% in gl using the intersection of descendents of i in acc and parents of j
% in gu. The bounds may contain cycles.
%
%inputs
% gu= upper bound
% gl=lower bound
% acc=initial upper bound/error free accessibility matrix
%outputs
%s=list of separatoids

if (size(gu,1)==size(gu,2) && isequal(size(gl),size(gu)) )
    diff=abs(gu-gl);
    diff(diff>0)=1;
    n=length(gu);
else
    error('Invalid Input. Input valid upper and lowr bounds');
end

f=acc;
f(f>0)=1;
prostho=max(20,floor(sqrt(n)));
s=zeros(n^2,prostho);
l=1;
mk=0;
for i=1:n
    for j=1:n
        if (i~=j && diff(i,j)==1)
            sep=(f(i,:).*gu(:,j)'); %descendents of i in acc and parents of j in gu
            sep(1,[i j])=0;
            nk=nnz(sep);
            if (nk~=0)
                m=find(sep);
                s(l,1:2)=[i j];
                mk=max(mk,nk);
                for k=1:nk
                    s(l,2+k)=m(k);
                end
                l=l+1;
            end
        end
    end
end

s=s(1:l-1,1:mk+2);
return