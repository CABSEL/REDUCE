function [gu_new,gl_new]=bound_update(gu,gl,alpha,v_ko,row,edges,vko_data,row_data)
% this matlab script implements update of bound using data from experiments
% designed by reduce.
% the algorithm is described in detail
% in our manuscript titled: "optimal design of gene knock-out
% experiments for inferring gene regulatory networks".
%
%
% inputs:
% gu: the upper bound matrix of the grn ensemble
% gl: the lower bound matrix of the grn ensemble
%   gu and gl matrices should be set such that the (i,j)-th element is 1
%   when the edge (i,j) belongs to the bound, and 0 otherwise.
% alpha: the cutoff for two sample t-test
% v_ko: the (optimal) set (a vector of gene indices) of genes KO to obtain
%   the background expression levels
% rows: the set of genes which are perturbed individually in
%   the background of v_ko KO (a vector of gene indices)
% edges: the set of uncertain edges to be verified by the v_ko
%   experiment. the first column gives the indices of the regulating genes,
%   and the second column gives the indices of the regulated genes.
% vko_data:  the expression profile of the v_ko KO in
%    Each row in the file correspond to a replicate of the
%    data while each column represent genes.
% row_data: data from KO of VKO + 1 gene from I_star
% outputs:
% gu_new: the the updated upper bound
% gl_new: the updated lower bound


if ~isempty(intersect(row,v_ko)); %check that
    warning('Inconsistent:KO','The rows and the v_ko should have no common element.')
end

n=size(gu,2);

set_edges=zeros(1,size(edges,1)); %converts the list of edges in to an empty set

for ii=1:size(edges,1)
    i=edges(ii,1);
    j=edges(ii,2);
    set_edges(ii)=sub2ind([n,n],i,j); %convert i,j to single number
end


for i=1:n
    edge=sub2ind([n,n],row,i);%convert row,i to single number
    if ismember(edge,set_edges)%check if it is testable by the v_ko
        x=vko_data(:,i);
        y=row_data(:,i);
        check= ttest2(x,y,alpha,'both', 'unequal');
        if check==1
            gl(edge)=1;
            gu(edge)=1;
        elseif check==0
            gu(edge)=0;
            gl(edge)=0;
            
        end
    end
end

gu_new=gu;
gl_new=gl;
end