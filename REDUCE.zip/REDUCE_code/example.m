% The following script gives an example on how to use of REDUCE MATLAB 
% subroutines to design optimal KO experiments and to use the resulting
% gene expression profiles to update the upper and lower bound of the GRN
% ensemble. 
% The procedure in this script comprises steps involved in one iteration
% of the proposed iterative network inference in our manuscript. 
% REDUCE algorithm and the iteratire network inference procedure are  
% described in detail in our manuscript titled: 
% "Optimal design of gene knock-out experiments for inferring gene 
% regulatory networks".

% In the first part of the script, we show how to use reduce.m to generate
% the optimal KO experiment.

% reduce.m requires as inputs the initial upper and lower bound of the 
% ensemble in the form of matrices, denote gu and gl respectively.
% gu and gl matrices should be set such that the (i,j)-th element is 1
% when the edge (i,j) belongs to the bound, and 0 otherwise.

gu_file='GU.tsv'; %assign filename containing the upper bound matrix
gl_file='GL.tsv'; %assign filename containing the lower bound matrix
gu=dlmread(gu_file); %read upper bound matrix
gl=dlmread(gl_file); %read lower bound matrix

% We can also assign genes to be excluded from KO experiments in a form of 
% a vector of indices of the said gene.
essential_set=[75,5,4,9]; %setting indices of genes to be excluded from KO

% In addition, we can also limit the number of genes in the optimal V_KO.
max_ko=1; % setting maximum number of genes in V_KO

% Running REDUCE to generate the optimal KO experiments
% Please type "help reduce" to get detailed information regarding the 
% outputs of reduce.m
[vko_star,i_star,e_star]=reduce(gu,gl,essential_set,max_ko)

% We should obtain the following outputs.
vko_star = 17;

i_star = [22    64];

e_star = [22    64
    64     5
    64     7
    64    27
    64    31
    64    44
    64    93
    64    94
    64    95
    64    96];
%
% Note that since GA is a stochastic optimization algorithm, reduce.m 
% may not always return the same outputs as above.
%
% In the following, we assume that the KO experiments have been performed
% and that we have data from KO of V_KO and from KO of V_KO and each gene
% listed in I_star.
% Now we are ready to update the upper and lower bound based on the new
% expression profiles. 

alpha=0.01; %Setting significance level for two sample t-test

% Loading the data from file. 
% For microarray data, the data matrix contains normalized fluorescence 
% intensity readings. The row indices correspond to the indices of the
% experimental replicates, while the column indices correspond to the 
% indices of the genes. 

% Loading data for VKO knock out
data_vko_file='data_vko.tsv'; %Setting filename containing expression profile of v_ko KO
v_ko_data=dlmread(data_vko_file,'\t',1,0); %Read data for v_ko KO

% Setting filename for data file from VKO + 1 gene in I_star KO
data_row_file='data_row'; 

for j=1:length(i_star)
    %Load data from KO of VKO + 1 gene from I_star
    data_row_file_j=strcat(data_row_file,num2str(j),'.tsv'); 
    row_data=dlmread(data_row_file_j,'\t',1,0);
    
    %Perform bound update
    [gu,gl]=bound_update(gu,gl,...
        alpha,vko_star,i_star(j),e_star,v_ko_data,row_data);
end

% If desired, write the updated upper and lower bounds to file
dlmwrite('GU_new.tsv',gu); 
dlmwrite('GL_new.tsv',gl); 

% The expected upper and lower bounds from running this example code can 
% be found in the files GU_example.tsv and GL_example.tsv.