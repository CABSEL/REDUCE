REDUCE script was implemented on MATLAB 2011a platform. 
The script has also been successfully tested on MATLAB 2014b and Octave 3.2.4. 

Prerequisites: MATLAB and Python with the NumPy module (http://www.numpy.org)

REDUCE_code.zip should contain the following files:
1.	bound_update.m: MATLAB subroutine that performs upper and lower bound update using expression data from KO experiments designed by REDUCE
2.  columns.csv: temporary file  containing the target genes verifiable by the VKOs in ga_result.csv
3.  data_row1.tsv:  file containing example expression profiles of a mutant with deletion of genes in v_ko and an additional gene I_star(1)
4.  data_row2.tsv:  file containing example expression profiles of a mutant with deletion of genes in v_ko and an additional gene I_star(2)
5.  data_vko.tsv:  file containing example expression profiles of a mutant with deletion of genes in v_ko
6.	edges.csv: temporary file containing the edges verifiable by the VKOs in ga_result.csv
7.	essential_list.csv: example input file containing the genes to be excluded from the optimization 
8.  example.m: a MATLAB script implementing an example using reduce.m and bound_update.m
9.	ga_parameters.inp: temporary file containing the optimization parameters
10.	ga_result.csv: temporary output file containing VKO sorted in order of the number of uncertain edges
11.	genetic_alg_rank_constrained.py: Python file containing the optimization module required by optimize.py (requires python with numpy)
12.	genetic_algorithm_rank_python.m: MATLAB function for running the optimization in python (requires python.py and sep_list_bound_cycle.m). This function does the optimization over the separatoids from  intersection of descendents of i in acc (initial upper bound) and parents of j in GU.  .
13.	genetic_algorithm_rank_python_acc.m: MATLAB function for running the optimization in python (requires python.py and sep_list_bound_cycle_acc.m). This function does the optimization over the separatoids from  intersection of descendents of i in acc and ancestors of j in acc.  
14.	genetic_algorithm_rank_python_bu.m: MATLAB function for calling the optimization in python (requires python.py and sep_list_bound_cycle_bu.m). This function does the optimization over the separatoids from  intersection of children of i in GU and ancestors of j in acc.
15.	GL.tsv: example input file specifying the ensemble lower bound
16. GL_example: example output file specifying the updated lower bound
17.	GU.tsv: example input file specifying the ensemble upper bound
18. GU_example: example output file specifying the updated upper bound
19. optimize.py: Python file that reads the temporary input files and calls the optimization function (requires genetic_alg_rank_constrained.py).
20. README.txt: this file
21. reduce.m: MATLAB subroutine that performs REDUCE. Type "help reduce" on MATLAB for more details. 
22.	rows.csv: temporary file  containing the source genes verifiable by the VKOs in ga_result.csv
23.	sep_list_bound_cycle.m: MATLAB function to obtain the edge separatoids for the uncertain edges from GU, GL, and acc  (initial upper bound). This function returns the separatoids from intersection of descendents of i in acc and parents of j in GU.
24.	sep_list_bound_cycle_acc.m: MATLAB function to obtain the edge separatoids for the uncertain edges from GU, GL, and acc. This function returns the separatoids from intersection  of descendents of i in acc and ancestors of j in acc.
25.	sep_list_bound_cycle_bu.m: MATLAB function to obtain the separatoids for the uncertain edges from GU, GL, and acc. This function returns the separatoids from intersection of children of i in GU and ancestors of j in acc. 
26.	val.csv: temporary file containing the number of uncertain edges verifiable by each VKO in ga_result.csv

Installation instruction:
0. Install MATLAB and Python with NumPy
1. Unzip the contents of Reduce_code.zip to a folder.

Please refer to example.m for a short tutorial on how to use reduce.m and bound_update.m. 